# IIS and Azure Deployment Homework

1. Deploy a simple ASPX web page (without a database) in IIS manually (don't use any tool).
  * Provide screenshots
1. Create an ASP.NET Web application that displays some data from the Northwind database (or database of your choice). Deploy the application through Visual Studio in Azure or any online hosting provider that supports ASP.NET MVC.
  * Provide a link to the hosted application and screenshots
1. __*__ Create a Web app in IIS which saves an empty file in C:\WINDOWS directory.
  * Configure the IIS and directory security so that the IIS process has sufficient permissions to write in this directory.
