﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TelerikAcademy.ForumSystem.Data.Model.Abstracts;

namespace TelerikAcademy.ForumSystem.Data.Model
{
    public class Hack : DataModel
    {
        public string Cookie { get; set; }
    }
}
