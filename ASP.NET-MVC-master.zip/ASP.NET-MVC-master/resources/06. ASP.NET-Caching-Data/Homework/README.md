# ASP.NET Caching Data Homework
1. Create new project from the default ASP.NET MVC application template and:
    - Make home page cacheable for 1 hour
    - Create cacheable partial view
2. Add a new razor view that shows the list of all files in a given directory and caches them till the directory changes.
