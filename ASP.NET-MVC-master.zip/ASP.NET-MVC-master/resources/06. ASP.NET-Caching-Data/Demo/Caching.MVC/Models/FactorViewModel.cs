﻿namespace Caching.MVC.Models
{
    public class FactorViewModel
    {
        public string Purpose { get; set; }
    }
}