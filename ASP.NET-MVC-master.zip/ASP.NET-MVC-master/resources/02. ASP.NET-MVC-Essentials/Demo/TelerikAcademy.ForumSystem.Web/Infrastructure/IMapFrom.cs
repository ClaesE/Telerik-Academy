﻿namespace TelerikAcademy.ForumSystem.Web.Infrastructure
{
    public interface IMapFrom<T>
    {
    }
}