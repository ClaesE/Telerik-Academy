﻿namespace TelerikAcademy.ForumSystem.Data.SaveContext
{
    public interface ISaveContext
    {
        void Commit();
    }
}