﻿namespace TelerikAcademy.ForumSystem.Services.Contracts
{
    public interface IService
    {
    }
}
