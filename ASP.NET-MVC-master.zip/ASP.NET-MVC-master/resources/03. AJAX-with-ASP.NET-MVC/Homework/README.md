# AJAX with ASP.NET MVC Homework
1. Create a database for storing information about Movies – Title, Director, Year, Leading Male Role, Leading Female Role and their Age, Studio, Studio Address.
1. Create Controllers and Actions for performing CRUD operations over the database.
1. Create an application that visualize and do operations with your data via Ajax.    