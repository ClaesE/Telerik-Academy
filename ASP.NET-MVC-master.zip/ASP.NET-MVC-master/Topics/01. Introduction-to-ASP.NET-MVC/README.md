<!-- section start -->
<!-- attr: { id:'title', class:'slide-title', hasScriptWrapper:true } -->
# ASP.NET Overview

<div class="signature">
    <p class="signature-course">ASP.NET MVC</p>
    <p class="signature-initiative">Telerik Software Academy</p>
    <a href="http://academy.telerik.com" class="signature-link">http://academy.telerik.com</a>
</div>


<!-- section start -->
<!-- attr: { class:'slide-section' } -->
# ASP.NET MVC
##  Overview

# ASP.NET MVC
- ASP.NET MVC is a web application framework
  - Developed by Microsoft
  - Implements the MVC pattern by design
  - Open-source software
  - Built on top of ASP.NET
- ASP.NET is one of the primary frameworks to create web applications with .NET
  - Along with ASP.NET Web Forms and ASP.NET Web Pages

<!-- section start -->

# Applications with ASP.NET MVC



<!-- section start -->
<!-- attr: { id:'questions', class:'slide-section' } -->
# Questions
## ASP.NET MVC
[link to the forum](http://telerikacademy.com/Forum/Category/55/asp-net-mvc)
