﻿# Course Schedule 2016
| №  | Lecture                                | Duration | Day | Date  | Time  | Who      |
|----|----------------------------------------|----------|-----|-------|-------|----------|
| 00 | Въведение в курса                      | 0.5h     | Mon | 01.02 | 18:00 | Niki     |
| 01 | Въведение в ASP.NET MVC                | 2h       | Mon | 01.02 | 18:30 | Niki     |
| 02 | Основи на ASP.NET MVC - част 1         | 2.5h     | Tue | 02.02 | 18:00 | Niki     |
| 02 | Основи на ASP.NET MVC - част 2         | 2.5h     | Wed | 03.02 | 18:00 | Ivo      |
| 03 | AJAX в ASP.NET                         | 2h       | Thu | 04.02 | 18:00 | Koceto   |
| 04 | Работа с данни                         | 3.5h     | Fri | 05.02 | 18:00 | Ivo      |
| 05 | Уеб сигурност и ASP.NET                | 2h       | Mon | 08.02 | 18:00 | Niki     |
| 08 | Деплоймънт в IIS и Azure               | 2h       | Mon | 08.02 | 20:00 | Niki     |
| 07 | Advanced ASP.NET MVC                   | 2h       | Tue | 09.02 | 18:00 | Ivo      |
| -- | **Workshop:** ASP.NET MVC Architecture | 4h       | Wed | 10.02 | 10:00 | Niki     |
| 06 | Кеширане на данни                      | 1.5h     | Thu | 11.02 | 18:00 | Ivo      |
| 09 | SignalR                                | 1h       | Thu | 11.02 | 20:00 | Ivo      |
| 10 | KendoUI ASP.NET MVC Wrappers           | 4h       | Fri | 12.02 | 18:00 | Ivo      |
| -- | **Workshop:** Подготовка за изпит      | 4h       | Mon | 15.02 | 17:00 | Niki     |
| 11 | ASP.NET Core 1.0                       | 2h       | Tue | 16.02 | 18:00 | Ivo      |
| -- | Практически изпит                      | all day  | Fri | 19.02 | 10:00 | Trainers |
| -- | Защита на индивидуалните проекти       | all day  | Wed | 24.02 | 10:00 | Trainers |
